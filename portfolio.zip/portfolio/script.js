// Footer year
document.getElementById('year').textContent = new Date().getFullYear();

// Theme toggle (light / dark)
const themeToggle = document.getElementById('themeToggle');
const root = document.documentElement;

function updateToggleLabel(){
  const current = root.getAttribute('data-theme');
  themeToggle.setAttribute('aria-label', current === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
}
updateToggleLabel();

themeToggle.addEventListener('click', () => {
  const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  root.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  updateToggleLabel();
});

// Mobile nav toggle
const navToggle = document.getElementById('navToggle');
const mainNav = document.getElementById('mainNav');

navToggle.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
});

mainNav.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    mainNav.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
  });
});

// Contact form validation
const form = document.getElementById('contactForm');
const successMsg = document.getElementById('formSuccess');

const fields = {
  name: {
    input: document.getElementById('name'),
    error: document.getElementById('nameError'),
    validate: (v) => v.trim().length >= 2 ? '' : 'Please enter your name.'
  },
  email: {
    input: document.getElementById('email'),
    error: document.getElementById('emailError'),
    validate: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) ? '' : 'Please enter a valid email address.'
  },
  message: {
    input: document.getElementById('message'),
    error: document.getElementById('messageError'),
    validate: (v) => v.trim().length >= 10 ? '' : 'Message should be at least 10 characters.'
  }
};

function validateField(key){
  const { input, error, validate } = fields[key];
  const message = validate(input.value);
  input.closest('.field').classList.toggle('has-error', Boolean(message));
  error.textContent = message;
  return !message;
}

Object.keys(fields).forEach(key => {
  fields[key].input.addEventListener('blur', () => validateField(key));
  fields[key].input.addEventListener('input', () => {
    if (fields[key].input.closest('.field').classList.contains('has-error')) {
      validateField(key);
    }
  });
});

form.addEventListener('submit', (e) => {
  e.preventDefault();
  successMsg.textContent = '';

  const results = Object.keys(fields).map(validateField);
  const allValid = results.every(Boolean);

  if (allValid) {
    successMsg.textContent = "Thanks — your message is ready to send. (Connect this form to an email service or backend to make it live.)";
    form.reset();
    Object.values(fields).forEach(f => {
      f.input.closest('.field').classList.remove('has-error');
      f.error.textContent = '';
    });
  } else {
    successMsg.textContent = '';
  }
});
